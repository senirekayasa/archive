# project
Free CC0 3D Models under Public Domain License.
---
This site exist from <a href="https://github.com/mohamadrido/cards-jekyll-theme">Cards Jekyll Theme - Responsive Column Cards</a> with some features:
- Clean homepage three cards
- Related cards post from sub-categories
- Navigation post
- Pagination post
- 404 not found
- SEO tag
- Analytics
- Google adsense
- Cookie notification

You can fork and custom this theme from <a href="https://github.com/mohamadrido/cards-jekyll-theme">here</a>. To remove the footer credit, you can <a href="https://mohamadrido.com/contact">contact</a> to Mohamad Rido for about it or just buy me coffee to <a href="https://paypal.me/mohamadrido">PayPal</a>.
